const PRODUCTION_BASE_URL = "https://services.santimpay.com/api/v1/gateway";
const TEST_BASE_URL = "https://testnet.santimpay.com/api/v1/gateway";

module.exports = {
  PRODUCTION_BASE_URL,
  TEST_BASE_URL,
};
